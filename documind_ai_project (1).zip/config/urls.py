from django.contrib import admin
from django.urls import path
from documents import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("api/upload/", views.upload_document, name="upload_document"),
    path("api/ask/", views.ask_question, name="ask_question"),
    path("api/documents/", views.list_documents, name="list_documents"),
]
