const fileInput = document.getElementById("fileInput");
const browseBtn = document.getElementById("browseBtn");
const dropZone = document.getElementById("dropZone");
const welcomePanel = document.getElementById("welcomePanel");
const workspacePanel = document.getElementById("workspacePanel");
const documentList = document.getElementById("documentList");
const toast = document.getElementById("toast");
const questionInput = document.getElementById("questionInput");
const sendBtn = document.getElementById("sendBtn");
const chatMessages = document.getElementById("chatMessages");
let activeDocumentId = null;
let activeDocumentTitle = "";

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 5500);
}
function getCookie(name) {
  const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return match ? decodeURIComponent(match[2]) : "";
}
function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[ch]));
}
function selectDocument(doc) {
  activeDocumentId = doc.id;
  activeDocumentTitle = doc.title;
  welcomePanel.classList.add("d-none");
  workspacePanel.classList.remove("d-none");
  document.getElementById("activeDocTitle").textContent = doc.title;
  document.getElementById("activeDocMeta").textContent =
    `${doc.page_count} page(s)/section(s) · ${doc.chunk_count} searchable chunks`;
  chatMessages.innerHTML = `<div class="assistant-message"><div class="avatar">✦</div><div><div class="message-label">DOCUMIND AI</div><div class="bubble">Your document is ready. Ask a question and I'll search its contents for relevant passages.</div></div></div>`;
  document.querySelectorAll(".doc-item").forEach(el => el.classList.toggle("selected", Number(el.dataset.id) === Number(doc.id)));
}
function renderDocumentList(documents) {
  if (!documents.length) {
    documentList.innerHTML = '<div class="muted small">No documents yet</div>';
    return;
  }
  documentList.innerHTML = documents.map(doc => `
    <button class="doc-item ${Number(doc.id) === Number(activeDocumentId) ? "selected" : ""}"
      data-id="${Number(doc.id)}" title="${escapeHtml(doc.title)}">▤ ${escapeHtml(doc.title)}</button>
  `).join("");
  documentList.querySelectorAll(".doc-item").forEach(button => {
    button.addEventListener("click", () => {
      const doc = documents.find(item => Number(item.id) === Number(button.dataset.id));
      if (doc?.status === "ready") selectDocument(doc);
      else showToast("This document is not ready yet.");
    });
  });
}
async function refreshDocuments() {
  try {
    const response = await fetch("/api/documents/");
    const data = await response.json();
    if (data.ok) renderDocumentList(data.documents);
  } catch (_) { /* The page can still be used if list refresh fails. */ }
}
async function uploadFile(file) {
  if (!file) return;
  const ext = file.name.split(".").pop().toLowerCase();
  if (!["pdf", "txt"].includes(ext)) {
    showToast("Choose a PDF or TXT file.");
    return;
  }
  const original = browseBtn.textContent;
  browseBtn.disabled = true;
  browseBtn.textContent = "Processing document…";
  const form = new FormData();
  form.append("file", file);
  try {
    const response = await fetch("/api/upload/", {
      method: "POST",
      headers: {"X-CSRFToken": getCookie("csrftoken")},
      body: form
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "Upload failed.");
    selectDocument(data.document);
    await refreshDocuments();
    showToast("Document indexed successfully. You can now ask questions.");
  } catch (error) {
    showToast(error.message || "Upload failed. Please try again.");
  } finally {
    browseBtn.disabled = false;
    browseBtn.textContent = original;
    fileInput.value = "";
  }
}
function addUserMessage(text) {
  const node = document.createElement("div");
  node.className = "user-message";
  node.innerHTML = `<div><div class="message-label">YOU</div><div class="bubble">${escapeHtml(text)}</div></div>`;
  chatMessages.appendChild(node);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}
function addAssistantMessage(answer, sources = []) {
  const node = document.createElement("div");
  node.className = "assistant-message";
  const sourceHtml = sources.length ? `
    <div class="sources"><div class="sources-heading">SOURCES FROM YOUR DOCUMENT</div>
    ${sources.map((source, i) => `<div class="source-card">
      <strong>Source ${i + 1} · ${escapeHtml(source.document)} · Page/section ${escapeHtml(source.page)}</strong>
      <p>${escapeHtml(source.snippet)}</p>
      <div class="source-score">Retrieval similarity: ${escapeHtml(source.score)}</div>
    </div>`).join("")}</div>` : "";
  node.innerHTML = `<div class="avatar">✦</div><div><div class="message-label">DOCUMIND AI</div><div class="bubble">${escapeHtml(answer)}</div>${sourceHtml}</div>`;
  chatMessages.appendChild(node);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}
async function askQuestion() {
  const question = questionInput.value.trim();
  if (!question) return;
  if (!activeDocumentId) {
    showToast("Upload or select a document first.");
    return;
  }
  questionInput.value = "";
  addUserMessage(question);
  sendBtn.disabled = true;
  sendBtn.textContent = "…";
  const loading = document.createElement("div");
  loading.className = "assistant-message";
  loading.innerHTML = '<div class="avatar">✦</div><div><div class="message-label">DOCUMIND AI</div><div class="bubble">Searching your document and preparing an answer…</div></div>';
  chatMessages.appendChild(loading);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  try {
    const response = await fetch("/api/ask/", {
      method: "POST",
      headers: {"Content-Type": "application/json", "X-CSRFToken": getCookie("csrftoken")},
      body: JSON.stringify({document_id: activeDocumentId, question})
    });
    const data = await response.json();
    loading.remove();
    if (!response.ok || !data.ok) throw new Error(data.error || "Could not answer the question.");
    addAssistantMessage(data.answer, data.sources);
  } catch (error) {
    loading.remove();
    addAssistantMessage(error.message || "Something went wrong. Please try again.");
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "↑";
    questionInput.focus();
  }
}
browseBtn.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => uploadFile(fileInput.files[0]));
dropZone.addEventListener("dragover", event => { event.preventDefault(); dropZone.classList.add("dragging"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragging"));
dropZone.addEventListener("drop", event => {
  event.preventDefault(); dropZone.classList.remove("dragging");
  uploadFile(event.dataTransfer.files[0]);
});
sendBtn.addEventListener("click", askQuestion);
questionInput.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); askQuestion(); }
});
document.querySelectorAll(".suggestion").forEach(button => button.addEventListener("click", () => {
  if (!activeDocumentId) { showToast("Upload a document first, then try this question."); return; }
  questionInput.value = button.dataset.question;
  askQuestion();
}));
document.getElementById("newChatBtn").addEventListener("click", () => {
  activeDocumentId = null;
  welcomePanel.classList.remove("d-none");
  workspacePanel.classList.add("d-none");
  document.querySelectorAll(".doc-item").forEach(el => el.classList.remove("selected"));
});
document.getElementById("documentsNav").addEventListener("click", () => {
  welcomePanel.classList.remove("d-none");
  workspacePanel.classList.add("d-none");
});
refreshDocuments();
