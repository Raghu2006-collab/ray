import json
import os
from pathlib import Path

from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from django.views.decorators.http import require_GET, require_POST
from django.views.decorators.csrf import ensure_csrf_cookie
from django.core.files.uploadedfile import UploadedFile

from .models import Document, ChatMessage
from .rag import process_document, retrieve, answer_question

@ensure_csrf_cookie
def home(request):
    return render(request, "documents/index.html")

def _json_error(message, status=400):
    return JsonResponse({"ok": False, "error": message}, status=status)

@require_POST
def upload_document(request):
    uploaded = request.FILES.get("file")
    if not uploaded:
        return _json_error("Choose a PDF or TXT file first.")
    max_mb = int(os.getenv("MAX_UPLOAD_MB", "20"))
    if uploaded.size > max_mb * 1024 * 1024:
        return _json_error(f"File is too large. Maximum size is {max_mb} MB.")
    suffix = Path(uploaded.name).suffix.lower()
    if suffix not in {".pdf", ".txt"}:
        return _json_error("Only PDF and TXT files are supported.")
    if suffix == ".pdf" and uploaded.content_type not in {"application/pdf", "application/octet-stream"}:
        return _json_error("The uploaded PDF has an unexpected content type.")

    doc = Document.objects.create(
        title=Path(uploaded.name).name[:255],
        file=uploaded,
        file_type=suffix[1:],
        status="processing",
    )
    try:
        process_document(doc)
    except Exception as exc:
        doc.status = "failed"
        # Avoid returning provider secrets or stack traces to the browser.
        doc.error_message = str(exc)[:1000]
        doc.save(update_fields=["status", "error_message"])
        return JsonResponse({
            "ok": False,
            "document_id": doc.id,
            "error": f"Document processing failed: {doc.error_message}",
        }, status=500)

    return JsonResponse({
        "ok": True,
        "document": {
            "id": doc.id,
            "title": doc.title,
            "status": doc.status,
            "page_count": doc.page_count,
            "chunk_count": doc.chunk_count,
        },
    })

@require_GET
def list_documents(request):
    documents = Document.objects.order_by("-uploaded_at")[:50]
    return JsonResponse({"ok": True, "documents": [
        {
            "id": doc.id,
            "title": doc.title,
            "status": doc.status,
            "page_count": doc.page_count,
            "chunk_count": doc.chunk_count,
            "uploaded_at": doc.uploaded_at.isoformat(),
        } for doc in documents
    ]})

@require_POST
def ask_question(request):
    try:
        payload = json.loads(request.body.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return _json_error("Invalid JSON request.")
    question = str(payload.get("question", "")).strip()
    document_id = payload.get("document_id")
    if not question:
        return _json_error("Type a question first.")
    if len(question) > 2000:
        return _json_error("Question is too long. Please keep it under 2,000 characters.")
    if not document_id:
        return _json_error("Upload or select a document first.")
    doc = get_object_or_404(Document, id=document_id)
    if doc.status != "ready":
        return _json_error("This document is not ready for questions yet.")
    try:
        sources = retrieve(doc, question)
        answer = answer_question(question, sources)
    except Exception as exc:
        return _json_error(f"Could not answer this question: {str(exc)[:500]}", status=500)

    ChatMessage.objects.create(document=doc, role="user", content=question)
    ChatMessage.objects.create(document=doc, role="assistant", content=answer)
    return JsonResponse({
        "ok": True,
        "answer": answer,
        "sources": [{
            "document": item["document_title"],
            "page": item["page"],
            "snippet": item["text"][:500],
            "score": round(item["score"], 3),
        } for item in sources],
    })
