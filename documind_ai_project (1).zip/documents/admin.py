from django.contrib import admin
from .models import Document, ChatMessage

@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ("title", "file_type", "status", "uploaded_at")
    list_filter = ("status", "file_type")
    search_fields = ("title",)

@admin.register(ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("document", "role", "created_at")
    list_filter = ("role",)
