# DocuMind AI — Django RAG Document Assistant

A starter college project that accepts PDF/TXT documents, extracts and chunks text, generates Gemini embeddings, retrieves relevant passages with FAISS, and generates context-grounded answers with source references.

## Requirements
- Python 3.10+
- Internet connection for Gemini API calls
- A Gemini API key
- Windows, macOS, or Linux

## 1. Create and activate a virtual environment

Open a terminal in the project folder.

### Windows PowerShell
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
```

If PowerShell blocks script execution, use this for the current terminal only:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

### Windows Command Prompt (CMD)
```cmd
py -m venv venv
venv\Scripts\activate.bat
```

### macOS/Linux
```bash
python3 -m venv venv
source venv/bin/activate
```

If `py` is unavailable on Windows, try `python` instead.

## 2. Install dependencies
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

FAISS wheels are available for many common Python/OS combinations. If installation fails, check your Python version and platform compatibility.

## 3. Configure Gemini
1. Copy `.env.example` to a new file named `.env`.
2. Replace `replace_with_your_api_key` with your own Gemini API key.
3. Keep `.env` private and never commit it to GitHub.

The default models can be changed using `GEMINI_MODEL` and `GEMINI_EMBEDDING_MODEL` in `.env` if they are unavailable for your account or region.

## 4. Run database migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

## 5. Start the server
```bash
python manage.py runserver
```

Open http://127.0.0.1:8000/ in your browser.

## How the RAG pipeline works
1. Upload PDF/TXT.
2. Extract text and retain PDF page numbers.
3. Split text into overlapping chunks.
4. Generate embeddings with Gemini.
5. Store vectors in a per-document FAISS index.
6. Embed the question and retrieve similar chunks.
7. Send retrieved passages to Gemini to generate an answer.
8. Return answer and citations based on retrieved chunk metadata.

## Important limitations and security notes
- This is a local development/college-project starter, not production-hardened.
- It has no login or per-user authorization yet. Do not deploy it publicly or use it for confidential documents without adding authentication, authorization, quotas, and secure storage.
- Uploaded files and indexes are stored under `media/`; they are excluded from Git.
- Scanned PDFs need OCR; this starter reports when no selectable text can be extracted.
- The retrieval similarity threshold is only a starting point. Evaluate it with your own sample questions and documents.
- Gemini API calls send document chunks/questions to the configured provider. Do not upload sensitive documents unless you have permission and understand the provider's data policies.
- Source snippets show retrieved passages. A cited passage is evidence shown to the user, not a guarantee that every generated claim is correct.
- For a real deployment, add user authentication, rate limiting, file content validation, malware scanning, background processing, retention/deletion controls, and production settings.

## Suggested demo
Use a short text-searchable PDF with known facts. Ask one question answered in the document, then ask a question that the document does not answer. Verify the returned snippets and page numbers.
